/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-12-19 18:51:41
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `sex` varchar(255) NOT NULL,
  `home` varchar(255) NOT NULL,
  `info` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('13', '于珊珊', '12345', 'null', '寿光', 'javaweb测试');
INSERT INTO `user` VALUES ('15', '张英树', '120650', '13280741922', '聊城', 'null');
INSERT INTO `user` VALUES ('17', '', '', '', 'null', 'null');
INSERT INTO `user` VALUES ('18', '李亚军', '120650', '1234567894', 'null', 'null');
INSERT INTO `user` VALUES ('19', '张张张', '120650', '17863523220', 'null', 'null');
